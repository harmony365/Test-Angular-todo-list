export const environment = {
    production: true,
    baseURL: 'http://localhost:3000/'
  };
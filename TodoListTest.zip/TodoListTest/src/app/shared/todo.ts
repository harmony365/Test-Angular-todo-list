export interface Todo {
    userId: number;
    id: number;
    task: string;
    status: boolean;
}
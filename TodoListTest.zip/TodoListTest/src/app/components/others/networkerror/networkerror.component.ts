import { Component } from '@angular/core';

@Component({
  selector: 'app-networkerror',
  templateUrl: './networkerror.component.html',
  styleUrls: ['./networkerror.component.scss']
})
export class NetworkerrorComponent {

}
